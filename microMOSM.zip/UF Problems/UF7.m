function PopObj = UF7(X)
    D  = size(X,2);
    J1 = 3 : 2 : D;
    J2 = 2 : 2 : D;
    Y  = X - sin(6*pi*repmat(X(:,1),1,D)+repmat(1:D,size(X,1),1)*pi/D);
    PopObj(:,1) = X(:,1).^0.2   + 2*mean(Y(:,J1).^2,2);
    PopObj(:,2) = 1-X(:,1).^0.2 + 2*mean(Y(:,J2).^2,2);
    PopObj=PopObj';
end