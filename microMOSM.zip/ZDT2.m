function PopObj = ZDT2( PopDec )
    PopObj(:,1) = PopDec(:,1);
    g = 1 + 9*mean(PopDec(:,2:end),2);
    h = 1 - (PopObj(:,1)./g).^2;
    PopObj(:,2) = g.*h;
    PopObj=PopObj' ;

end

